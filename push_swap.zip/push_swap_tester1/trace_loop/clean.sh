rm -rf output*.txt
rm -rf test_case*.txt
